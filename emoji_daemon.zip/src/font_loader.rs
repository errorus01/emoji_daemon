use windows::core::{IUnknown, Interface, Result};
use windows::Win32::Graphics::DirectWrite::{
    IDWriteFactory, IDWriteFactory5, IDWriteFontCollection, IDWriteFontFile,
    IDWriteFontSetBuilder1, IDWriteInMemoryFontFileLoader,
};

pub static CUSTOM_EMOJI_FONT: &[u8] = include_bytes!("../assets/Twemoji.Mozilla.ttf");

pub unsafe fn create_in_memory_font_collection(
    factory: &IDWriteFactory,
    font_bytes: &'static [u8],
) -> Result<IDWriteFontCollection> {
    let factory5: IDWriteFactory5 = factory.cast()?;

    let memory_loader: IDWriteInMemoryFontFileLoader =
        factory5.CreateInMemoryFontFileLoader()?;

    // КРИТИЧЕСКИ ВАЖНО: регистрируем наш лоадер памяти в DirectWrite
    factory5.RegisterFontFileLoader(&memory_loader)?;

    let font_file: IDWriteFontFile = memory_loader.CreateInMemoryFontFileReference(
        &factory5,
        font_bytes.as_ptr() as *const _,
        font_bytes.len() as u32,
        None::<&IUnknown>,
    )?;

    let builder: IDWriteFontSetBuilder1 = factory5.CreateFontSetBuilder()?;
    builder.AddFontFile(&font_file)?;
    let font_set = builder.CreateFontSet()?;

    let collection = factory5.CreateFontCollectionFromFontSet(&font_set)?;
    collection.cast()
}