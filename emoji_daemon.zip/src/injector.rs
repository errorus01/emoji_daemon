use std::thread::sleep;
use std::time::Duration;
use windows::Win32::Foundation::HWND;
use windows::Win32::UI::Input::KeyboardAndMouse::{
    SendInput, INPUT, INPUT_0, KEYBDINPUT, KEYEVENTF_KEYUP, KEYEVENTF_UNICODE,
};
use windows::Win32::UI::WindowsAndMessaging::SetForegroundWindow;

pub fn insert_emoji(target_hwnd: HWND, emoji: &str) {
    unsafe {
        // 1. Возвращаем фокус окну, где стоял курсор
        if !target_hwnd.is_invalid() {
            let _ = SetForegroundWindow(target_hwnd);
            // Микропауза 25-30мс, чтобы винда успела передать фокус потоку целевого окна
            sleep(Duration::from_millis(30));
        }

        // 2. Кодируем строку в UTF-16 суррогаты
        let utf16_units: Vec<u16> = emoji.encode_utf16().collect();
        let mut inputs = Vec::with_capacity(utf16_units.len() * 2);

        for &code in &utf16_units {
            // Key Down
            inputs.push(INPUT {
                r#type: windows::Win32::UI::Input::KeyboardAndMouse::INPUT_KEYBOARD,
                Anonymous: INPUT_0 {
                    ki: KEYBDINPUT {
                        wVk: windows::Win32::UI::Input::KeyboardAndMouse::VIRTUAL_KEY(0),
                        wScan: code,
                        dwFlags: KEYEVENTF_UNICODE,
                        time: 0,
                        dwExtraInfo: 0,
                    },
                },
            });

            // Key Up
            inputs.push(INPUT {
                r#type: windows::Win32::UI::Input::KeyboardAndMouse::INPUT_KEYBOARD,
                Anonymous: INPUT_0 {
                    ki: KEYBDINPUT {
                        wVk: windows::Win32::UI::Input::KeyboardAndMouse::VIRTUAL_KEY(0),
                        wScan: code,
                        dwFlags: KEYEVENTF_UNICODE | KEYEVENTF_KEYUP,
                        time: 0,
                        dwExtraInfo: 0,
                    },
                },
            });
        }

        // 3. Отправляем в очередь сообщений каретки
        SendInput(&inputs, std::mem::size_of::<INPUT>() as i32);
    }
}