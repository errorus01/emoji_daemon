#![windows_subsystem = "windows"]

mod font_loader;
mod hotkey;
mod injector;
mod window;

use window::EmojiApp;
use windows::core::HSTRING;
use windows::Win32::UI::WindowsAndMessaging::{MessageBoxW, MB_ICONERROR, MB_OK};

fn main() {
    if let Err(e) = EmojiApp::run() {
        unsafe {
            let error_msg = HSTRING::from(format!("Ошибка инициализации пикера:\n{:?}", e));
            let title = windows::core::w!("Emoji Daemon Error");
            let _ = MessageBoxW(
                None,
                windows::core::PCWSTR(error_msg.as_ptr()),
                title,
                MB_OK | MB_ICONERROR,
            );
        }
    }
}