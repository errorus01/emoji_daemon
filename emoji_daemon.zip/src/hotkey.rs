use windows::Win32::Foundation::HWND;
use windows::Win32::UI::Input::KeyboardAndMouse::{
    RegisterHotKey, UnregisterHotKey, HOT_KEY_MODIFIERS, MOD_ALT, MOD_CONTROL, MOD_NOREPEAT,
};

pub const HOTKEY_ID: i32 = 0x1337;

pub fn register_hotkey(hwnd: HWND) -> bool {
    unsafe {
        // Ctrl + Alt + E (0x45 = код клавиши 'E')
        // MOD_NOREPEAT чтобы при зажатии не спамило окнами как из пулемета
        RegisterHotKey(
            Some(hwnd),
            HOTKEY_ID,
            HOT_KEY_MODIFIERS(MOD_CONTROL.0 | MOD_ALT.0 | MOD_NOREPEAT.0),
            0x45,
        )
        .is_ok()
    }
}

pub fn unregister_hotkey(hwnd: HWND) {
    unsafe {
        let _ = UnregisterHotKey(Some(hwnd), HOTKEY_ID);
    }
}