use std::cell::RefCell;
use windows::core::{w, Result};
use windows::Win32::Foundation::{HINSTANCE, HWND, LPARAM, LRESULT, POINT, WPARAM};
use windows::Win32::Graphics::Direct2D::Common::{D2D1_COLOR_F, D2D_RECT_F, D2D_SIZE_U};
use windows::Win32::Graphics::Direct2D::{
    D2D1CreateFactory, ID2D1Factory, ID2D1HwndRenderTarget, ID2D1SolidColorBrush,
    D2D1_DRAW_TEXT_OPTIONS_ENABLE_COLOR_FONT, D2D1_FACTORY_TYPE_SINGLE_THREADED,
    D2D1_HWND_RENDER_TARGET_PROPERTIES, D2D1_PRESENT_OPTIONS_NONE,
    D2D1_RENDER_TARGET_PROPERTIES,
};
use windows::Win32::Graphics::DirectWrite::{
    DWriteCreateFactory, IDWriteFactory, IDWriteTextFormat, DWRITE_FACTORY_TYPE_SHARED,
    DWRITE_FONT_STRETCH_NORMAL, DWRITE_FONT_STYLE_NORMAL, DWRITE_FONT_WEIGHT_BOLD,
    DWRITE_FONT_WEIGHT_NORMAL, DWRITE_MEASURING_MODE_NATURAL,
    DWRITE_PARAGRAPH_ALIGNMENT_CENTER, DWRITE_TEXT_ALIGNMENT_CENTER,
};
use windows::Win32::Graphics::Gdi::{InvalidateRect, ValidateRect};
use windows::Win32::System::LibraryLoader::GetModuleHandleW;
use windows::Win32::System::Threading::{GetCurrentProcess, SetProcessWorkingSetSize};
use windows::Win32::UI::Input::KeyboardAndMouse::ReleaseCapture;
use windows::Win32::UI::WindowsAndMessaging::{
    CreateWindowExW, DefWindowProcW, DispatchMessageW, GetCursorPos, GetForegroundWindow,
    GetMessageW, PostQuitMessage, RegisterClassExW, SendMessageW, SetForegroundWindow,
    SetWindowPos, ShowWindow, TranslateMessage, CS_HREDRAW, CS_VREDRAW, CW_USEDEFAULT,
    HTCAPTION, HWND_TOPMOST, MSG, SWP_SHOWWINDOW, SW_HIDE, WA_INACTIVE, WNDCLASSEXW,
    WS_BORDER, WS_EX_TOOLWINDOW, WS_EX_TOPMOST, WS_POPUP, WM_ACTIVATE, WM_DESTROY,
    WM_HOTKEY, WM_LBUTTONDOWN, WM_LBUTTONUP, WM_MOUSEMOVE, WM_MOUSEWHEEL,
    WM_NCLBUTTONDOWN, WM_PAINT,
};

use crate::hotkey::{register_hotkey, unregister_hotkey, HOTKEY_ID};
use crate::injector::insert_emoji;
use crate::font_loader::{create_in_memory_font_collection, CUSTOM_EMOJI_FONT};

// Расширенный набор эмодзи
pub const EMOJI_LIST: &[&str] = &[
    // Смайлы и рожи
    "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "🥲", "🥹", "☺️", "😊",
    "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋",
    "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎", "🥸", "🤩", "🥳", "😏",
    "😒", "😞", "😔", "😟", "😕", "🙁", "☹️", "😣", "😖", "😫", "😩", "🥺",
    "😢", "😭", "😮‍💨", "😤", "😠", "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱",
    "😨", "😰", "😥", "😓", "🫣", "🤗", "🫡", "🤔", "🫣", "🤫", "🫠", "🤐",
    "🤨", "😐", "😑", "😶", "🫥", "😶‍🌫️", "😏", "😒", "🙄", "😬", "🤥", "🫨",
    // Жесты и руки
    "👍", "👎", "👊", "✊", "🤛", "🤜", "👏", "🙌", "👐", "🤲", "🤝", "🙏",
    "✌️", "🤞", "🫰", "🤟", "🤘", "👌", "🤌", "🤏", "👈", "👉", "👆", "👇",
    // Разное, айтишное и огонь
    "🔥", "✨", "🎉", "🚀", "💀", "💩", "👀", "🦀", "💡", "💻", "⚙️", "⚡",
    "❤️", "💔", "💯", "😴", "🤮", "📦", "☕", "🎮", "👾", "🛡️", "🎯", "☣️",
];

const COLS: i32 = 6;
const CELL_SIZE: i32 = 46;
const HEADER_HEIGHT: i32 = 28;
const VISIBLE_ROWS: i32 = 5;

const WIN_WIDTH: i32 = COLS * CELL_SIZE; // 276 px
const WIN_HEIGHT: i32 = HEADER_HEIGHT + (VISIBLE_ROWS * CELL_SIZE); // 258 px

thread_local! {
    static APP_STATE: RefCell<Option<WindowState>> = const { RefCell::new(None) };
}

struct WindowState {
    hwnd: HWND,
    prev_hwnd: HWND,
    d2d_factory: ID2D1Factory,
    render_target: Option<ID2D1HwndRenderTarget>,
    _dwrite_factory: IDWriteFactory,
    emoji_format: IDWriteTextFormat,
    header_format: IDWriteTextFormat,
    hovered_index: Option<usize>,
    scroll_y: f32,
    total_rows: i32,
}

impl WindowState {
    fn max_scroll(&self) -> f32 {
        let content_height = (self.total_rows * CELL_SIZE) as f32;
        let view_height = (VISIBLE_ROWS * CELL_SIZE) as f32;
        (content_height - view_height).max(0.0)
    }

    /// Срезает рабочий набор процесса до минимума в ОЗУ
    fn trim_memory(&self) {
        unsafe {
            let _ = SetProcessWorkingSetSize(GetCurrentProcess(), usize::MAX, usize::MAX);
        }
    }
}

pub struct EmojiApp;

impl EmojiApp {
    pub fn run() -> Result<()> {
        unsafe {
            let instance: HINSTANCE = GetModuleHandleW(None)?.into();
            let class_name = w!("EmojiDaemonPickerClass");

            let wnd_class = WNDCLASSEXW {
                cbSize: std::mem::size_of::<WNDCLASSEXW>() as u32,
                lpfnWndProc: Some(wnd_proc),
                hInstance: instance,
                lpszClassName: class_name,
                style: CS_HREDRAW | CS_VREDRAW,
                ..Default::default()
            };

            RegisterClassExW(&wnd_class);

            let hwnd = CreateWindowExW(
                WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
                class_name,
                w!("Emoji Picker"),
                WS_POPUP | WS_BORDER,
                CW_USEDEFAULT,
                CW_USEDEFAULT,
                WIN_WIDTH,
                WIN_HEIGHT,
                None,
                None,
                Some(instance),
                None,
            )?;

            let d2d_factory: ID2D1Factory =
                D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, None)?;
            let dwrite_factory: IDWriteFactory = DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED)?;

            // 1. Создаем кастомную коллекцию из вшитого в память Twemoji
            let custom_collection =
                create_in_memory_font_collection(&dwrite_factory, CUSTOM_EMOJI_FONT)?;

            // 2. Имя семейства внутри файла Twemoji.Mozilla.ttf строго: "Twemoji Mozilla"
            let emoji_format = dwrite_factory.CreateTextFormat(
                w!("Twemoji Mozilla"),
                Some(&custom_collection), // <-- Передаем нашу коллекцию вместо None!
                DWRITE_FONT_WEIGHT_NORMAL,
                DWRITE_FONT_STYLE_NORMAL,
                DWRITE_FONT_STRETCH_NORMAL,
                22.0,
                w!("en-US"),
            )?;
            emoji_format.SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER)?;
            emoji_format.SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER)?;

            // Формат для заголовка шапки
            let header_format = dwrite_factory.CreateTextFormat(
                w!("Segoe UI"),
                None,
                DWRITE_FONT_WEIGHT_BOLD,
                DWRITE_FONT_STYLE_NORMAL,
                DWRITE_FONT_STRETCH_NORMAL,
                11.0,
                w!("en-US"),
            )?;
            header_format.SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER)?;
            header_format.SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER)?;

            let total_rows = ((EMOJI_LIST.len() as i32) + COLS - 1) / COLS;

            register_hotkey(hwnd);

            APP_STATE.with(|state| {
                let st = WindowState {
                    hwnd,
                    prev_hwnd: HWND::default(),
                    d2d_factory,
                    render_target: None,
                    _dwrite_factory: dwrite_factory,
                    emoji_format,
                    header_format,
                    hovered_index: None,
                    scroll_y: 0.0,
                    total_rows,
                };
                st.trim_memory();
                *state.borrow_mut() = Some(st);
            });

            // Цикл сообщений Win32
            let mut msg = MSG::default();
            while GetMessageW(&mut msg, None, 0, 0).into() {
                let _ = TranslateMessage(&msg);
                DispatchMessageW(&msg);
            }

            unregister_hotkey(hwnd);
            Ok(())
        }
    }
}

unsafe extern "system" fn wnd_proc(
    hwnd: HWND,
    msg: u32,
    wparam: WPARAM,
    lparam: LPARAM,
) -> LRESULT {
    match msg {
        WM_HOTKEY => {
            if wparam.0 == HOTKEY_ID as usize {
                let foreground = GetForegroundWindow();

                let mut pt = POINT::default();
                let _ = GetCursorPos(&mut pt);

                APP_STATE.with(|state| {
                    if let Some(s) = state.borrow_mut().as_mut() {
                        s.prev_hwnd = foreground;
                    }
                });

                let _ = SetWindowPos(
                    hwnd,
                    Some(HWND_TOPMOST),
                    pt.x,
                    pt.y,
                    WIN_WIDTH,
                    WIN_HEIGHT,
                    SWP_SHOWWINDOW,
                );
                let _ = SetForegroundWindow(hwnd);
            }
            LRESULT(0)
        }

        // Зажатие мыши: если кликнули по шапке — перетаскиваем окно!
        // Зажатие мыши: если кликнули по шапке — перетаскиваем окно!
        WM_LBUTTONDOWN => {
            let y = ((lparam.0 >> 16) & 0xFFFF) as i32;
            if y < HEADER_HEIGHT {
                let _ = ReleaseCapture();
                let _ = SendMessageW(
                    hwnd,
                    WM_NCLBUTTONDOWN,
                    Some(WPARAM(HTCAPTION as usize)),
                    Some(LPARAM(0)),
                );
            }
            LRESULT(0)
        }

        // Скроллинг колесиком мыши
        WM_MOUSEWHEEL => {
            let delta = ((wparam.0 >> 16) as i16) as f32;
            APP_STATE.with(|state| {
                if let Some(s) = state.borrow_mut().as_mut() {
                    let max = s.max_scroll();
                    // Скроллим на 1 строку (CELL_SIZE) за щелчок колеса
                    let step = (CELL_SIZE as f32) * (delta / 120.0);
                    s.scroll_y = (s.scroll_y - step).clamp(0.0, max);
                    let _ = InvalidateRect(Some(hwnd), None, false);
                }
            });
            LRESULT(0)
        }

        WM_ACTIVATE => {
            if (wparam.0 & 0xFFFF) == WA_INACTIVE as usize {
                let _ = ShowWindow(hwnd, SW_HIDE);
                // Жесткий сброс памяти при скрытии в трей/фон
                APP_STATE.with(|state| {
                    if let Some(s) = state.borrow().as_ref() {
                        s.trim_memory();
                    }
                });
            }
            LRESULT(0)
        }

        WM_MOUSEMOVE => {
            let x = (lparam.0 & 0xFFFF) as i32;
            let y = ((lparam.0 >> 16) & 0xFFFF) as i32;

            APP_STATE.with(|state| {
                if let Some(s) = state.borrow_mut().as_mut() {
                    let mut new_hover = None;

                    // Ховер работает только ниже шапки
                    if y >= HEADER_HEIGHT {
                        let content_y = (y - HEADER_HEIGHT) as f32 + s.scroll_y;
                        let col = x / CELL_SIZE;
                        let row = (content_y / CELL_SIZE as f32) as i32;

                        if col >= 0 && col < COLS && row >= 0 && row < s.total_rows {
                            let idx = (row * COLS + col) as usize;
                            if idx < EMOJI_LIST.len() {
                                new_hover = Some(idx);
                            }
                        }
                    }

                    if s.hovered_index != new_hover {
                        s.hovered_index = new_hover;
                        let _ = InvalidateRect(Some(hwnd), None, false);
                    }
                }
            });
            LRESULT(0)
        }

        WM_LBUTTONUP => {
            let x = (lparam.0 & 0xFFFF) as i32;
            let y = ((lparam.0 >> 16) & 0xFFFF) as i32;

            if y >= HEADER_HEIGHT {
                let mut chosen_emoji = None;
                let mut prev = HWND::default();

                APP_STATE.with(|state| {
                    if let Some(s) = state.borrow().as_ref() {
                        prev = s.prev_hwnd;
                        let content_y = (y - HEADER_HEIGHT) as f32 + s.scroll_y;
                        let col = x / CELL_SIZE;
                        let row = (content_y / CELL_SIZE as f32) as i32;

                        if col >= 0 && col < COLS && row >= 0 && row < s.total_rows {
                            let idx = (row * COLS + col) as usize;
                            if let Some(&emoji) = EMOJI_LIST.get(idx) {
                                chosen_emoji = Some(emoji);
                            }
                        }
                    }
                });

                if let Some(emoji) = chosen_emoji {
                    let _ = ShowWindow(hwnd, SW_HIDE);
                    insert_emoji(prev, emoji);
                    APP_STATE.with(|state| {
                        if let Some(s) = state.borrow().as_ref() {
                            s.trim_memory();
                        }
                    });
                }
            }
            LRESULT(0)
        }

        WM_PAINT => {
            APP_STATE.with(|state| {
                if let Some(s) = state.borrow_mut().as_mut() {
                    let _ = render_ui(s);
                }
            });
            let _ = ValidateRect(Some(hwnd), None);
            LRESULT(0)
        }

        WM_DESTROY => {
            PostQuitMessage(0);
            LRESULT(0)
        }

        _ => DefWindowProcW(hwnd, msg, wparam, lparam),
    }
}

unsafe fn render_ui(state: &mut WindowState) -> Result<()> {
    if state.render_target.is_none() {
        let size = D2D_SIZE_U {
            width: WIN_WIDTH as u32,
            height: WIN_HEIGHT as u32,
        };
        let rt_props = D2D1_RENDER_TARGET_PROPERTIES::default();
        let hwnd_props = D2D1_HWND_RENDER_TARGET_PROPERTIES {
            hwnd: state.hwnd,
            pixelSize: size,
            presentOptions: D2D1_PRESENT_OPTIONS_NONE,
        };
        state.render_target =
            Some(state.d2d_factory.CreateHwndRenderTarget(&rt_props, &hwnd_props)?);
    }

    let rt = state.render_target.as_ref().unwrap();
    rt.BeginDraw();

    // Фон контента: глубокий темный #1A1A1A
    rt.Clear(Some(&D2D1_COLOR_F {
        r: 0.10,
        g: 0.10,
        b: 0.10,
        a: 1.0,
    }));

    let hover_brush: ID2D1SolidColorBrush = rt.CreateSolidColorBrush(
        &D2D1_COLOR_F {
            r: 0.22,
            g: 0.22,
            b: 0.25,
            a: 1.0,
        },
        None,
    )?;

    let text_brush: ID2D1SolidColorBrush = rt.CreateSolidColorBrush(
        &D2D1_COLOR_F {
            r: 1.0,
            g: 1.0,
            b: 1.0,
            a: 1.0,
        },
        None,
    )?;

    // 1. Отрисовка смайликов с куллингом (рисуем ТОЛЬКО видимые на экране)
    let visible_top = state.scroll_y;
    let visible_bottom = state.scroll_y + (VISIBLE_ROWS * CELL_SIZE) as f32;

    for (idx, emoji) in EMOJI_LIST.iter().enumerate() {
        let col = (idx as i32) % COLS;
        let row = (idx as i32) / COLS;

        let item_top = (row * CELL_SIZE) as f32;
        let item_bottom = item_top + CELL_SIZE as f32;

        // Отсекаем всё, что выше или ниже видимой области
        if item_bottom < visible_top || item_top > visible_bottom {
            continue;
        }

        let left = (col * CELL_SIZE) as f32;
        let draw_top = item_top - state.scroll_y + (HEADER_HEIGHT as f32);

        let cell_rect = D2D_RECT_F {
            left,
            top: draw_top,
            right: left + CELL_SIZE as f32,
            bottom: draw_top + CELL_SIZE as f32,
        };

        if state.hovered_index == Some(idx) {
            rt.FillRectangle(&cell_rect, &hover_brush);
        }

        let utf16: Vec<u16> = emoji.encode_utf16().collect();
        rt.DrawText(
            &utf16,
            &state.emoji_format,
            &cell_rect,
            &text_brush,
            D2D1_DRAW_TEXT_OPTIONS_ENABLE_COLOR_FONT,
            DWRITE_MEASURING_MODE_NATURAL,
        );
    }

    // 2. Отрисовка шапки окна (Header) поверх контента
    let header_brush: ID2D1SolidColorBrush = rt.CreateSolidColorBrush(
        &D2D1_COLOR_F {
            r: 0.15,
            g: 0.15,
            b: 0.18,
            a: 1.0,
        },
        None,
    )?;

    let header_border_brush: ID2D1SolidColorBrush = rt.CreateSolidColorBrush(
        &D2D1_COLOR_F {
            r: 0.28,
            g: 0.28,
            b: 0.32,
            a: 1.0,
        },
        None,
    )?;

    let header_text_brush: ID2D1SolidColorBrush = rt.CreateSolidColorBrush(
        &D2D1_COLOR_F {
            r: 0.70,
            g: 0.70,
            b: 0.75,
            a: 1.0,
        },
        None,
    )?;

    let header_rect = D2D_RECT_F {
        left: 0.0,
        top: 0.0,
        right: WIN_WIDTH as f32,
        bottom: HEADER_HEIGHT as f32,
    };

    rt.FillRectangle(&header_rect, &header_brush);

    // Тонкая разделительная линия под шапкой
    let line_rect = D2D_RECT_F {
        left: 0.0,
        top: (HEADER_HEIGHT - 1) as f32,
        right: WIN_WIDTH as f32,
        bottom: HEADER_HEIGHT as f32,
    };
    rt.FillRectangle(&line_rect, &header_border_brush);

    // Заголовок в шапке (тяни за него!)
    let title = "EMOJI PICKER 🦀";
    let title_utf16: Vec<u16> = title.encode_utf16().collect();
    rt.DrawText(
        &title_utf16,
        &state.header_format,
        &header_rect,
        &header_text_brush,
        D2D1_DRAW_TEXT_OPTIONS_ENABLE_COLOR_FONT,
        DWRITE_MEASURING_MODE_NATURAL,
    );

    rt.EndDraw(None, None)?;
    Ok(())
}